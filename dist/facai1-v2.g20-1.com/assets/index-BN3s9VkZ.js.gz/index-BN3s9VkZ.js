
/**
 * 由 flying services 提供技术支持
 * Powered by Hector
 */
  
var e=Object.defineProperty,a=Object.defineProperties,r=Object.getOwnPropertyDescriptors,t=Object.getOwnPropertySymbols,s=Object.prototype.hasOwnProperty,o=Object.prototype.propertyIsEnumerable,n=(a,r,t)=>r in a?e(a,r,{enumerable:!0,configurable:!0,writable:!0,value:t}):a[r]=t;import{O as p,Y as i,H as c,b6 as l,a1 as u,af as b,S as d,a9 as f,aG as m,a3 as y,aL as g,aD as v,a_ as O,T as h,R as j,a2 as x}from"./vendor-kx7r3U2-.js";import{u as _,_ as w}from"./index-1kZVT1Y0.js";import{b as P}from"./bg-2-bcIQGS7T.js";const I={key:0,style:{width:"30px",height:"1px"}},S=p({name:"HomeHeader"});const H=w(p(a(((e,a)=>{for(var r in a||(a={}))s.call(a,r)&&n(e,r,a[r]);if(t)for(var r of t(a))o.call(a,r)&&n(e,r,a[r]);return e})({},S),r({props:["imgSrc"],setup(e){const{mediaQueryInfo:a}=i(_()),r=c(!1),t=l(),s=e;return(e,o)=>{const n=m;return j(),u(b,null,[d(n,{"offset-top":0,onChange:o[0]||(o[0]=e=>r.value=e)},{default:y((()=>o[1]||(o[1]=[f("div",null,null,-1)]))),_:1}),f("div",{class:O(["home-header",{"is-fixed":h(r)}]),style:v({"--top-height":"".concat(h(a).top,"px"),backgroundImage:h(r)?"url(".concat(s.imgSrc||h(P),")"):"unset"})},[g(e.$slots,"box",{},(()=>[h(t).box?x("",!0):(j(),u("div",I))]))],6)],64)}}}))),[["__scopeId","data-v-5353296a"]]);export{H as _};
