
/**
 * 由 flying services 提供技术支持
 * Powered by Hector
 */
  
var e=Object.defineProperty,r=Object.defineProperties,t=Object.getOwnPropertyDescriptors,i=Object.getOwnPropertySymbols,a=Object.prototype.hasOwnProperty,o=Object.prototype.propertyIsEnumerable,s=(r,t,i)=>t in r?e(r,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):r[t]=i;import{O as l,a1 as n,S as c,a3 as p,aO as m,a9 as b,T as f,R as g}from"./vendor-kx7r3U2-.js";import{_ as h}from"./index-C_qy4oKs.js";import{a as j}from"./allow-right-D2jpVseH.js";import"./buffer-BJ2qglEo.js";import"./index-1kZVT1Y0.js";import"./back_white_icon-8wmrRgZw.js";const u={class:"normal-page"},O=["src"],v=["src"],d=l({name:"ServiceReg"}),w=l(r(((e,r)=>{for(var t in r||(r={}))a.call(r,t)&&s(e,t,r[t]);if(i)for(var t of i(r))o.call(r,t)&&s(e,t,r[t]);return e})({},d),t({setup:e=>(e,r)=>{const t=h,i=m;return g(),n("div",u,[c(t,{title:"用户协议"}),c(i,{title:"服务协议","is-link":"",to:"/service-private"},{"right-icon":p((()=>[b("img",{src:f(j),width:"20",height:"20",alt:""},null,8,O)])),_:1}),c(i,{title:"隐私协议","is-link":"",to:"/reg-private"},{"right-icon":p((()=>[b("img",{src:f(j),width:"20",height:"20",alt:""},null,8,v)])),_:1})])}})));export{w as default};
